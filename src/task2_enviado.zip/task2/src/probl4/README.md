# Tarefa 2 -- Teoria da Computação -- 2021/2

**Definindo Computação & Açucar Sintático & Código como Dados, Dados como Código**
**Autor:** Pablo S Nascimento

## Problema 4.1

Escreva uma função em Clojure que receba como entrada o AST de um programaNAND-CIRC, i.e., uma sequência de dicionários de expressões do tipo ":assign", conforme exemplificado na Tabela 1, e retorne a representação em lista de tuplas deste programa.

**Solução**

A solução executa um loop na lista de entrada onde cada item é um comando NAND-CIRC em AST. Para cada comando NAND, extraio as variaveis envolvidas e gero uma saída com os trios das variaveis encontradas no left-side e as duas no rigth-side do comando NAND.

A solução deste problema faz uma leitura do AST buscando construir um conjunto contendo todas variáveis existentes, ordenando-os conforme interesse. Desse conjunto, separo as variáveis de entrada X, as variáveis de saída Y e as variáveis internas ao programa. Ordeno as variáveis de entrada e saída e as combino em um vetor conforme a ordem: variáveis de entrada - variaveis internas - variáveis de saída, respectivamente.

Por fim, construo a tupla com os tipos definidos.
 
**Execução**

 Para execução do programa basta executar, conforme:
 
 (println (representacao-lista-tuplas AST))
 
 onde AST é uma variavel definida no programa como sendo a leitura do conteúdo do arquivo nand.txt com o conteúdo AST na forma de lista de itens conforme arquivo de exemplo "nand.txt".
 
 
 ## Problema 4.2

Escreva uma função em Clojure que receba um trio com a representação em lista detuplas de P, um programa NAND-CIRC, e uma sequência de 0’s e 1’s representando asentradas de P, e retorna uma sequência de 0’s e 1’s representando as saídas de P.

**Solução**
A solução foi separar as variáveis em um vetor independente com as variáveis de entrada de forma única, identificando seus nomes (números), em ordem crescente e com seu respectivo valor a ser armazenado à frente da posição da variavel. Ex:
[0 0 1 0 2 0 3 1 4 1 5 0] Neste vetor, as variaveis 0, 1, 2 e 5 estão com valor 0 e as variaveis 3 e 4 estão com valor 1. Dessa forma ficou simples manter um vetor atualizado perpetuando a cada novo passo do loop atualizando os valores das variáveis à medida em que os comandos nand vão sendo interpretados. Ao final, retorno apenas os valores das últimas m variáveis, que são as de saída Y.

**Execução**
Para execução chamar função conforme exemplo:

(println (executa-nand "01" 2 LISTA_P))

onde "01" é o n de entrada, 2 é o valor de m da quantidade de variaveis na saída e LISTA_P é uma variável que lê uma lista de tuplas contidas no arquivo "L.txt"
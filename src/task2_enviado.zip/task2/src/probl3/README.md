# Tarefa 2 -- Teoria da Computação -- 2021/2

**Definindo Computação & Açucar Sintático & Código como Dados, Dados como Código**
**Autor:** Pablo S Nascimento

## Problema 3.1

Este problema pede uma implementação em NAND-CIRC-FOR para a função MULT3, ou seja, que multiplica
dois números de 3 bits.

**Solução**
A solução foi baseada na forma como calculamos naturalmente a multiplicação de 2 numeros inteiros, ou seja, multiplicando todos os digitos entre si e gerando os numeros resultantes de cada multiplicação.
Por fim, somamos esses fatores resultantes considerando o "shift-left" para cada casa decimal de maior ordem multiplicada.

Para solução em NAND-CIRC-FOR, foram implementados 3 for: o primeiro para estruturar as variaveis que recebrão os resultados das multiplicações; o segundo para efetuar a soma dos dois primeiros números resultantes da multiplicação e; o terceiro for para somar o resultado da soma anterior com o último número resultante da multiplicação. Como é uma multiplicação de numeros de 3 bits, temos 3 fatores para a soma.

**Execução**
Para execução, primeiro aplica-se o desugar no programa solucao_mult3.txt gerando a saída des_mult3.txt, conforme exemplo abaixo:

 java -jar ..\nand-circ-0.3.3-SNAPSHOT-standalone.jar -v nand -d for -a desugar < solucao_mult3.txt > des_mult3.txt
 
 Em seguida, aplicamos as definições de função para açucar sintatico de algumas funções e unimos os codigos em um só arquivo. Para isso, execute:
 
 cat des_mult3.txt >> definicao.txt
 
 Agora execute o arquivo definicao.txt com o comando, por exemplo:
 
 java -jar ..\nand-circ-0.3.3-SNAPSHOT-standalone.jar -v nand -d proc -a eval < definicao.txt 111001
 
 
 
 ## Problema 3.2

Este problema pede uma implementação em Clojure para gerar um código NAND-CIRC para a função MULTn, ou seja, que multiplica dois números de 2n bits.

**Solução**
A solução foi baseada na solução de implementação resultante do primeiro problema.
Em Clojure, repliquei a lógica e construí uma string de saída gravando em arquivo o programa final a ser executado.

Para solução usei for para preparar cada uma das partes do código final:
parte 1: fatores resultantes das multiplicações dos bits de entrada
parte 2: somas desses fatores
parte 3: saidas do programa

concatenei todas essas partes em uma string só que compões o problema.

**Execução**
Para execução, basta invocar a função em clojure, conforme exemplo abaixo:

(imprime-multn 4)

Irá gerar um arquivo mult4.txt com a solução da multiplicação de 2 números de 4 bits.

Para executar, chamar, por exemplo:

java -jar ..\nand-circ-0.3.3-SNAPSHOT-standalone.jar -v nand -d proc -a eval < mult4.txt 11110010



 ## Problema 3.3

Este problema pede uma demonstração ou refutação de que o número de linhas de código gerado pelo meu programa é de no máximo 1000.n^2.

**Solução**
A solução encontrada foi gerar diversos arquivos multn.txt para n entre 2 e 18, aplicar o desugar em todos para que possuíssem apenas linhas NAND e, por fim, contas o número de linhas. Plotar um gráfico dessas informações.

**Execução**
Para execução, no clojure, primeiro gerar os 18 arquivos, conforme exemplo abaixo:

(gera-arquivos 18)

Irá gerar arquivos mult2.txt, mult3.txt, mult4.txt... no diretório. Em seguida, executar o desugar.bat para aplicar desugar em todos eles, conforme exemplo abaixo:

desugar.bat
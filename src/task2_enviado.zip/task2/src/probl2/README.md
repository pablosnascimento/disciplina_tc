# Tarefa 2 -- Teoria da Computação -- 2021/2

**Definindo Computação & Açucar Sintático & Código como Dados, Dados como Código**
**Autor:** Pablo S Nascimento

## Problema 2.1

Este problema pede uma implementação em Clojure para interpretar o comando estruturado if conforme a sintaxe da linguagem NAND-CIRC.

**Solução**
A solução parte da leitura do AST e utilizando recursão, busca encontrar na estrutura de dados do Clojure que representa o AST cada comando
existente e replicado na saída, exceto quando trata-se de um if, que deverá ser interpretado para os comandos inline que os tratam.
Foram criadas funções auxiliares que são responáveis por recriar os comandos de atribuição conforme necessidade.

**Execução**
Função não finalizada.
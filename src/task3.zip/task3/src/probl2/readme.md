# Tarefa 3 -- Teoria da Computação -- 2021/2

**Funções com Domínios Infinitos, Autômatose Expressões Regulares & Loops e Infinitude & Modelos Equivalentes de Computação**
**Autor:** Pablo S Nascimento

## Problema 2

Este problema pede uma demonstração de que a linguagem Beta proposta é regular.

**Solução**
A solução foi construir um autômato que reconheça a linguagem.
Foi utilizado o site https://ivanzuzak.info/noam/webapps/fsm_simulator/ para criação e validação dos testes.
O código fonte do autômato está no arquivo definicao_automato.txt.

**Execução**
Submeter o fonte definicao_automato.txt ao site https://ivanzuzak.info/noam/webapps/fsm_simulator/ e testar.